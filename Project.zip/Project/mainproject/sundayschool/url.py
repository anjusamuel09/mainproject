from django.conf.urls import url

from sundayschool import views

urlpatterns=[
    url('login',views.log,name='login'),
    url('desig',views.desig,name='desig'),
    url('reg',views.reg,name='reg'),
    url('index',views.index,name='index'),
    url('stud',views.stud,name='stud'),
    url('teach',views.teach,name='teach'),
]