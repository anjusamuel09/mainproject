from django.db import models

# Create your models here.
class Login(models.Model):
    Username = models.CharField(max_length=50)
    Password = models.CharField(max_length=50)
    Role = models.CharField(max_length=20)
#class Designation(models.Model):
    #DesigName = models.CharField(max_length=50)
#class Teacher(models.Model):
    #DesigID = models.ForeignKey(Designation,on_delete=models.CASCADE)
   # Name = models.CharField(max_length=50)
   # BaptName = models.CharField(max_length=50)
    #Housename = models.CharField(max_length=50)
    #Address = models.CharField(max_length=100)
    #Gender = models.CharField(max_length=20)
    #DOB = models.DateField()
    #Qualification = models.CharField(max_length=50)
    #Age = models.IntegerField()
    #EmailID = models.EmailField()
    #Phno = models.IntegerField()
#class Mission(models.Model):
#class Student(models.Model):
 #   RollNo = models.IntegerField()
  #  Name = models.CharField(max_length=50)
   # BaptName = models.CharField(max_length=50)
    #Housename = models.CharField(max_length=50)
    #Address = models.CharField(max_length=100)
    #FatherName = models.CharField(max_length=50)
    #FOccupation = models.CharField(max_length=50)
    #MotherName = models.CharField(max_length=50)
    #MOccupation = models.CharField(max_length=50)
    #DOB = models.DateField()
    #GodFather = models.CharField(max_length=50)
    #GodMother = models.CharField(max_length=50)
    #DOE = models.DateField()
    #DOC = models.DateField()
    #Age = models.IntegerField()
    #Gender = models.CharField(max_length=50)
    #Phno = models.IntegerField()
    #EmailID = models.EmailField()
    #Class = models.CharField(max_length=10)


class Parent(models.Model):
    StudentID = models.ForeignKey(Student,on_delete=models.CASCADE)
    ParentName = models.CharField(max_length=50)
    Housename = models.CharField(max_length=100)
    Address = models.CharField(max_length=100)
    Occupation = models.CharField(max_length=50)
    NoOFChildren = models.IntegerField()






