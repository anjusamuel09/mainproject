from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from sundayschool.models import Login, Teacher, Designation


def index(request):
    return render(request,'index.html')
def log(request):
    return render(request,'index.html')
def reg(request):
    return render(request,'registration.html')
def desig(request):
    return render(request,'registration.html')
def stud(request):
    return render(request,'student.html')

def add(request):
     if request.method=='POST':
       name=request.POST.get('txtname')
       baptname=request.POST.get('txtbaptname')
       housename=request.POST.get('txthousename')
       address=request.POST.get('txtaddress')
       gender=request.POST.get('txtgender')
       dob = request.POST.get('txtdob')
       qualification = request.POST.get('txtquali')
       age = request.POST.get('txtage')
       emailid = request.POST.get('txtemail')
       phno = request.POST.get('txtphno')
       designame = request.POST.get('txtdesig')
       username = request.POST.get('txtusername')
       password = request.POST.get('txtpassword')
       obj = Teacher()
       obj.Name = name
       obj.BaptName = baptname
       obj.Housename = housename
       obj.Address = address
       obj.Gender = gender
       obj.DOB = dob
       obj.Qualification = qualification
       obj.Age = age
       obj.EmailID = emailid
       obj.Phno = phno
       obj.Password = password
       obj.save()
       objs=Login()
       objs.Username = username
       objs.Password= password
       # objs.role=des
       # obj.ids=objs
       objs.save()
       objss=Designation()
       objss.DesigName = designame
       objss.save()
     else:
         return render(request,'login.html')













